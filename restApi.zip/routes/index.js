var express = require('express');
var router = express.Router();
const path = require("path");
var JWT = require('jsonwebtoken');
var fs = require('fs');
const file = fs.readFileSync(path.resolve(__dirname, "./../config/web3Config.json"));
const Web3 = require('web3');
const web3configJson = JSON.parse(file);
const SignerProvider = require('ethjs-provider-signer');
const sign = require('ethjs-signer').sign;
const address = web3configJson.accounts[0];
const FaucetPrivateKey = web3configJson.FaucetPrivateKey[0];
const provider = new SignerProvider(
  web3configJson.rpc_url,
  {
    signTransaction: (rawTx, cb) =>
      cb(null, sign(rawTx, FaucetPrivateKey)),
    accounts: cb => cb(null, [address])
  }
);
const web3 = new Web3(provider);
const file2 = path.resolve(__dirname, "./../build/contracts/Scm.json");
const parsed = JSON.parse(fs.readFileSync(file2));
const contractaddress = web3configJson.contract_address[0];
const contract = new web3.eth.Contract(parsed.abi, contractaddress);

/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', { title: 'Express' });
});

// uint a,uint _age, string _fName, string _lName
router.post('/setData', function (req, res, next) {

  JWT.verify(req.token, '****', (err, authData) => {
    if (err) {
      res.sendStatus(403)
    } else {
      console.log(req.body.id);
      contract.methods.set(req.body.id, req.body.age, req.body.fname, req.body.lname)
        .send({
          from: address,
          gas: 9500000
        })
        .on('transactionHash', function (hash) {
          console.log(hash)
        })
        .on('confirmation', function (confirmationNumber, receipt) {
          console.log("Confirmed", confirmationNumber, receipt);
        })
        .on('receipt', function (receipt) {
          res.send(receipt)
        })
        .on("error", function (error) {
          res.send(error);
        });
    }
  });
});


router.post('/getData', function (req, res, next) {
  JWT.verify(req.token, '****', (err, authData) => {
    if (err) {
      res.sendStatus(403)
    } else {
      contract.methods.values(req.body.id).call({
        from: address
      }, (err, result) => {
        err ? res.send(err) : res.send(result);
      })
    }
  });
});





module.exports = router;
