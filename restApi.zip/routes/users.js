var express = require('express');
var router = express.Router();
var JWT = require('jsonwebtoken');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});


router.get('/adminAuthenticate', (req, res) => {
  var user = {
    "username": "Hari",
    "role": "admin"
  }
  //creating token
  JWT.sign(user, '****', { expiresIn:'3000s' } , (err, token) => {
    err ? res.json({
      "message": "error while generating token"
    }) : console.log(token);
    res.json({
      token
    });
  })
})

router.get('/Authenticate', (req, res) => {
  var user = {
    "username": "Hari",
    "role": "user"
  }
  //creating token
  JWT.sign(user, '****', { expiresIn:'3000s' } , (err, token) => {
    err ? res.json({
      "message": "error while generating token"
    }) : console.log(token);
    res.json({
      token
    });
  })
})

module.exports = router;
