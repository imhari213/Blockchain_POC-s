﻿# JsonWebToken

npm install to install dependencies

npm start   to run the application

Port : 3000

http://localhost:3000/Authenticate     -  to get JSON Authenticated Token

http://localhost:3000/users            - to get users         // pass Authorization in Headers as bellow examples


Authorization   :  Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6IkhhcmkiLCJwYXNzd29yZCI6ImFkbWluIiwiaWF0IjoxNTU2ODA5MzczLCJleHAiOjE1NTY4MDk0MDN9.mrLtLcBHjGNZsEcehnZcMYcz3rBmKny2Na2kMeU9tSs
