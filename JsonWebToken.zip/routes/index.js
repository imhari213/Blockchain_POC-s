var express = require('express');
var router = express.Router();
var JWT = require('jsonwebtoken');
/* GET home page. */
router.get('/', function (req, res, next) {
  res.render('index', {
    title: 'Express'
  });
});

router.get('/adminAuthenticate', (req, res) => {
  var user = {
    "username": "Hari",
    "role": "admin"
  }
  //creating token
  JWT.sign(user, 'Hari', { expiresIn:'3000s' } , (err, token) => {
    err ? res.json({
      "message": "error while generating token"
    }) : console.log(token);
    res.json({
      token
    });
  })
})

router.get('/Authenticate', (req, res) => {
  var user = {
    "username": "Hari",
    "role": "user"
  }
  //creating token
  JWT.sign(user, 'Hari', { expiresIn:'3000s' } , (err, token) => {
    err ? res.json({
      "message": "error while generating token"
    }) : console.log(token);
    res.json({
      token
    });
  })
})

router.get('/adminAccess',verifyToken, (req, res)=>{

  JWT.verify(req.token, 'Hari', (err, authData) => {
    if (err) {   
      console.log(err);   
      res.sendStatus(403)
    } else {
      if(authData.role == "admin"){
      var users = {
        "message": "Hello admin"       
      }
      res.json({
        users,
        authData
      });
    }else{
      res.json({"msg":"oopsss...! you are not allowed to Access Data"});
    }
    }
  })

})

router.get('/users', verifyToken, (req, res) => {

  JWT.verify(req.token, 'Hari', (err, authData) => {
    if (err) {
      res.sendStatus(403)
    } else {
      var users = {
        "user 1": "A",
        "user 2": "B",
        "user 3": "C",
        "user 4": "D"
      }
      res.json({
        users,
        authData
      });
    }
  })




})

function verifyToken(req, res, next) {
  var bearerheader = req.headers['authorization'];

  // console.log(bearerheader);
  // const Bearer = bearerheader.split('');
  // const beareToken = Bearer[1];
  // console.log(beareToken);
  if (typeof bearerheader !== undefined) {
    //console.log(bearerheader);
    const Bearer = bearerheader.split(' ');
  // console.log(Bearer);
    const beareToken = Bearer[1];
    console.log(beareToken);
    console.log(req.token,"req token");
    req.token = beareToken;
    next()
  } else {
    res.sendStatus(403);
  }
}


module.exports = router;