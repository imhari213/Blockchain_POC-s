var express = require('express');
var router = express.Router();
var JWT = require('jsonwebtoken');

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});


router.get('/usersObj', (req, res) => {

  JWT.verify(req.token, 'Har', (err, authData) => {
    if (err) {
      res.sendStatus(403)
    } else {
      var users = {
        "user 1": "A",
        "user 2": "B",
        "user 3": "C",
        "user 4": "D"
      }
      res.json({
        users,
        authData
      });
    }
  })

});

module.exports = router;
